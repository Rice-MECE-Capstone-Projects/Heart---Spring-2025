import pandas as pd
import librosa
import numpy as np
import os
from tqdm import tqdm

# --- 参数配置 ---
# 1. 定义CSV文件路径
TRAIN_CSV_PATH = r"D:\_Capstone_\2025_New_Project\training\train_set.csv"
VAL_CSV_PATH = r"D:\_Capstone_\2025_New_Project\training\validation_set.csv"

# 2. 定义保存频谱图的文件夹路径
# 最好在 training 文件夹下新建一个 'features' 文件夹来存放
OUTPUT_TRAIN_DIR = r"D:\_Capstone_\2025_New_Project\training\features\train"
OUTPUT_VAL_DIR = r"D:\_Capstone_\2025_New_Project\training\features\val"

# 3. 音频处理参数
# 为保证所有频谱图尺寸一致，我们需要固定采样率和音频长度
TARGET_SAMPLE_RATE = 44100 # 目标采样率
FIXED_DURATION_S = 5      # 将所有音频统一处理为5秒（长则截断，短则补零）
SAMPLES_TO_TAKE = TARGET_SAMPLE_RATE * FIXED_DURATION_S

# --- 确保输出文件夹存在 ---
os.makedirs(OUTPUT_TRAIN_DIR, exist_ok=True)
os.makedirs(OUTPUT_VAL_DIR, exist_ok=True)

# --- 特征提取核心函数 ---
def audio_to_melspectrogram(filepath, sr=TARGET_SAMPLE_RATE, max_len=SAMPLES_TO_TAKE):
    """
    加载音频文件，统一长度，并转换为梅尔频谱图。
    """
    try:
        # 1. 加载音频，librosa会自动重采样到目标采样率
        audio, _ = librosa.load(filepath, sr=sr)
        
        # 2. 统一音频长度
        if len(audio) > max_len:
            # 截断
            audio = audio[:max_len]
        else:
            # 补零
            padding = max_len - len(audio)
            audio = np.pad(audio, (0, padding), 'constant')
            
        # 3. 计算梅尔频谱图
        # n_mels是梅尔带的数量（图像的高度），fmax是考虑的最高频率
        mel_spec = librosa.feature.melspectrogram(y=audio, sr=sr, n_mels=128, fmax=8000)
        
        # 4. 转换为分贝（dB）单位，更符合人类听觉
        mel_spec_db = librosa.power_to_db(mel_spec, ref=np.max)
        
        return mel_spec_db
    
    except Exception as e:
        print(f"Error processing {filepath}: {e}")
        return None

# --- 批量处理函数 ---
def process_dataset(csv_path, output_dir):
    """
    读取CSV，遍历文件，转换并保存频谱图。
    """
    df = pd.read_csv(csv_path)
    
    for index, row in tqdm(df.iterrows(), total=df.shape[0]):
        filepath = row['filepath']
        label = row['label']
        
        # 从文件路径中获取不带后缀的文件名，作为新文件的名字
        base_filename = os.path.splitext(os.path.basename(filepath))[0]
        output_filepath = os.path.join(output_dir, f"{base_filename}.npy")
        
        # 提取梅尔频谱图
        mel_spectrogram = audio_to_melspectrogram(filepath)
        
        if mel_spectrogram is not None:
            # 使用numpy的save函数保存，.npy格式读取速度很快
            np.save(output_filepath, mel_spectrogram)

# --- 开始执行 ---
print("--- Starting processing of training set ---")
process_dataset(TRAIN_CSV_PATH, OUTPUT_TRAIN_DIR)

print("\n--- Starting processing of validation set ---")
process_dataset(VAL_CSV_PATH, OUTPUT_VAL_DIR)

print("\n--- All feature extraction completed! ---")