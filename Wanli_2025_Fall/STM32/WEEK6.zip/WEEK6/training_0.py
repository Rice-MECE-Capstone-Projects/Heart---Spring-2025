import pandas as pd
import os

# 1. 定义你的数据集根目录
# 注意：Windows路径中的反斜杠'\'需要转义，写成'\\'或者在字符串前加 r
base_data_path = r"D:\_Capstone_\2025_New_Project\training"

# 2. 定义所有子文件夹的名称
# os.listdir()可以自动获取文件夹下的所有目录名，更具扩展性
# 这里我们假设文件夹就是 a 到 f
sub_folders = ['training-a', 'training-b', 'training-c', 'training-d', 'training-e', 'training-f']

# 3. 创建一个空的列表，用来存放从每个REFERENCE.csv中读取的数据
all_data = []

print("Starting to process the dataset...")

# 4. 遍历每一个子文件夹
for folder_name in sub_folders:
    # 组合出当前子文件夹的完整路径
    folder_path = os.path.join(base_data_path, folder_name)
    
    # 组合出当前REFERENCE.csv文件的完整路径
    reference_file_path = os.path.join(folder_path, 'REFERENCE.csv')
    
    # 检查REFERENCE.csv是否存在
    if os.path.exists(reference_file_path):
        # 使用pandas读取CSV文件，并告诉它没有表头(header=None)
        df = pd.read_csv(reference_file_path, header=None)
        # 给读取的数据框设置列名
        df.columns = ['filename', 'label']
        
        # 核心步骤：为每个文件名创建完整的.wav文件路径
        # df['filename'].apply(...) 会对'filename'列中的每一个值执行一个操作
        # 这个操作就是将文件夹路径和文件名（加上.wav后缀）组合起来
        df['filepath'] = df['filename'].apply(
            lambda fname: os.path.join(folder_path, f"{fname}.wav")
        )
        
        # 将处理好的当前文件夹的数据（路径和标签）添加到总列表中
        all_data.append(df)
        print(f"Successfully processed folder: {folder_name}, found {len(df)} files.")
    else:
        print(f"Warning: REFERENCE.csv not found in folder {folder_name}.")

# 5. 将列表中的所有DataFrame合并成一个大的DataFrame
if all_data:
    master_df = pd.concat(all_data, ignore_index=True)

    # 6. (可选) 查看最终结果
    print("\nData processing completed!")
    print(f"A total of {len(master_df)} audio files were found.")
    print("\nExample of data (first 5 entries):")
    print(master_df.head())
    
    print("\nExample of data (last 5 entries):")
    print(master_df.tail())

    # 7. (可选) 将整合好的数据保存到一个新的CSV文件中，方便下次直接使用
    output_path = os.path.join(base_data_path, 'master_reference.csv')
    master_df.to_csv(output_path, index=False)
    print(f"\nAll data has been summarized and saved to: {output_path}")
else:
    print("\nProcessing failed, no data found.")