import tensorflow as tf
import numpy as np
import pandas as pd
import librosa
import os
import math
from sklearn.metrics import confusion_matrix, classification_report
import seaborn as sns
import matplotlib.pyplot as plt

# --- 1. 配置 ---
# 加载已经训练好的模型
MODEL_PATH = 'heart_sound_model.h5'
# 使用验证集数据进行验证
VAL_CSV_PATH = r"D:\_Capstone_\2025_New_Project\training\validation_set.csv"
FEATURES_BASE_DIR = r"D:\_Capstone_\2025_New_Project\training\features"

# 和训练时完全相同的音频处理参数
TARGET_SAMPLE_RATE = 44100
FIXED_DURATION_S = 5
SAMPLES_TO_TAKE = TARGET_SAMPLE_RATE * FIXED_DURATION_S
INPUT_SHAPE = (128, 431, 1)

# --- 2. 加载模型 ---
print(f"Loading model: {MODEL_PATH}")
model = tf.keras.models.load_model(MODEL_PATH)
print("Model loaded successfully!")
model.summary() # 打印一下模型结构确认

# --- 3. 核心功能：用于预测单个音频文件的函数 ---
def predict_single_audio(filepath, model):
    """
    对单个WAV文件进行完整的预处理和预测
    """
    # **关键**：这里的预处理步骤必须和训练时一模一样！
    try:
        # a. 加载音频并统一长度
        audio, _ = librosa.load(filepath, sr=TARGET_SAMPLE_RATE)
        if len(audio) > SAMPLES_TO_TAKE:
            audio = audio[:SAMPLES_TO_TAKE]
        else:
            padding = SAMPLES_TO_TAKE - len(audio)
            audio = np.pad(audio, (0, padding), 'constant')

        # b. 计算梅尔频谱图
        mel_spec = librosa.feature.melspectrogram(y=audio, sr=TARGET_SAMPLE_RATE, n_mels=128, fmax=8000)
        mel_spec_db = librosa.power_to_db(mel_spec, ref=np.max)

        # c. 调整输入形状以匹配模型
        # (128, 431) -> (1, 128, 431, 1)
        # 第一个 '1' 是 batch size，因为我们只预测一个样本
        mel_spec_db = np.expand_dims(mel_spec_db, axis=0)
        mel_spec_db = np.expand_dims(mel_spec_db, axis=-1)

        # d. 进行预测
        prediction_proba = model.predict(mel_spec_db)[0][0]

        # e. 解释结果
        predicted_class = 1 if prediction_proba > 0.5 else 0
        class_label = 'Abnormal' if predicted_class == 1 else 'Normal'
        
        print(f"\n--- Single File Diagnosis Report ---")
        print(f"File: {os.path.basename(filepath)}")
        print(f"Model output probability (Abnormal): {prediction_proba:.4f}")
        print(f"Final Diagnosis: {class_label}")

    except Exception as e:
        print(f"Error processing file {filepath}: {e}")

# --- 4. 执行验证 ---

# 4.1. 单文件预测示例
# 我们从验证集里随便挑一个文件来测试
val_df = pd.read_csv(VAL_CSV_PATH)
# 挑第一个文件为例
sample_wav_path = val_df.iloc[0]['filepath'] 
predict_single_audio(sample_wav_path, model)

# 4.2. (可选) 在整个验证集上再次进行评估，确认性能
print("\n--- Starting batch validation on the entire validation set ---")

# 使用我们之前写的生成器来加载数据
# (注意：这里为了演示，复制了生成器的简化版，实际项目中可以从另一个文件导入)
class ValidationGenerator(tf.keras.utils.Sequence):
    # 在初始化时，增加 batch_size 参数
    def __init__(self, csv_path, features_dir, batch_size):
        self.df = pd.read_csv(csv_path)
        self.features_dir = features_dir
        self.batch_size = batch_size
        self.filenames = self.df['filepath'].apply(lambda x: os.path.splitext(os.path.basename(x))[0]).tolist()
        self.labels = [1 if lbl == 1 else 0 for lbl in self.df['label'].tolist()]

    def __len__(self):
        # 正确计算批次数
        return math.ceil(len(self.filenames) / self.batch_size)

    def __getitem__(self, idx):
        # 获取一个批次的文件名
        batch_filenames = self.filenames[idx * self.batch_size:(idx + 1) * self.batch_size]
        
        # 创建一个正确形状的空数组来存放批次数据
        # 形状是 (批次大小, 高, 宽, 通道数)
        X = np.empty((len(batch_filenames), *INPUT_SHAPE))
        
        # 循环加载数据并填入批次数组
        for i, filename in enumerate(batch_filenames):
            spec_path = os.path.join(self.features_dir, f"{filename}.npy")
            spectrogram = np.load(spec_path)
            # 添加通道维度并赋值给批次数据
            X[i,] = np.expand_dims(spectrogram, axis=-1)
            
        # 返回一个完整的、4维的批次数据
        return X

BATCH_SIZE = 32 
val_features = ValidationGenerator(VAL_CSV_PATH, os.path.join(FEATURES_BASE_DIR, 'val'), BATCH_SIZE)

# predict() 在生成器上运行时，会自动分批次处理
predictions_proba = model.predict(val_features, verbose=1)
y_pred = (predictions_proba > 0.5).astype(int)
y_true = np.array(val_features.labels)

# 打印混淆矩阵和分类报告
cm = confusion_matrix(y_true, y_pred)
class_names = ['Normal', 'Abnormal']
plt.figure(figsize=(8, 6))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=class_names, yticklabels=class_names)
plt.title('Confusion Matrix on Validation Set')
plt.ylabel('True Label')
plt.xlabel('Predicted Label')
plt.show()

print("\n--- Classification Report ---")
print(classification_report(y_true, y_pred, target_names=class_names))