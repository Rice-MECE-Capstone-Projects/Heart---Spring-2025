import pandas as pd
import numpy as np
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense, Dropout, Input
from tensorflow.keras.utils import Sequence
from tensorflow.keras.callbacks import TensorBoard, EarlyStopping, ModelCheckpoint
import os
import math
import datetime
import shutil
import random

# --- 新增：评估和可视化所需的库 ---
from sklearn.metrics import confusion_matrix, classification_report
import seaborn as sns
import matplotlib.pyplot as plt

# --- 核心修改：加强版的随机种子设置函数 ---
def set_seed(seed=10):
    """
    设置所有相关的随机种子，并强制使用确定性算法，以确保实验的完全可复现性。
    """
    os.environ['PYTHONHASHSEED'] = str(seed)
    os.environ['TF_DETERMINISTIC_OPS'] = '1'  # 早期版本的TF需要这个
    random.seed(seed)
    np.random.seed(seed)
    tf.random.set_seed(seed)
    # --- 关键补充：强制TensorFlow使用确定性操作，解决多worker问题 ---
    tf.config.experimental.enable_op_determinism()
    print(f"Random seed set to {seed}, and op determinism is enabled.")

# 在程序开始时调用这个函数
set_seed(5)


# --- 1. 参数和路径配置 ---
# 和上一个脚本保持一致
TRAIN_CSV_PATH = r"D:\_Capstone_\2025_New_Project\training\train_set.csv"
VAL_CSV_PATH = r"D:\_Capstone_\2025_New_Project\training\validation_set.csv"
FEATURES_BASE_DIR = r"D:\_Capstone_\2025_New_Project\training\features"

# 模型训练参数
BATCH_SIZE = 32
# 现在有了EarlyStopping，可以把EPOCHS设得大一些，程序会自动在最佳时机停止
EPOCHS = 50 
INPUT_SHAPE = (128, 431, 1)

# --- 2. 创建数据生成器 (Data Generator) ---
class HeartSoundGenerator(Sequence):
    def __init__(self, csv_path, features_dir, batch_size, is_train=True):
        self.df = pd.read_csv(csv_path)
        self.features_dir = features_dir
        self.batch_size = batch_size
        self.is_train = is_train
        self.filenames = self.df['filepath'].apply(lambda x: os.path.splitext(os.path.basename(x))[0]).tolist()
        self.labels = [1 if lbl == 1 else 0 for lbl in self.df['label'].tolist()]
        if self.is_train:
            self.on_epoch_end()

    def __len__(self):
        return math.ceil(len(self.filenames) / self.batch_size)

    def __getitem__(self, idx):
        batch_filenames = self.filenames[idx * self.batch_size:(idx + 1) * self.batch_size]
        batch_labels = self.labels[idx * self.batch_size:(idx + 1) * self.batch_size]
        X, y = self.__data_generation(batch_filenames, batch_labels)
        return X, y

    def on_epoch_end(self):
        if self.is_train:
            combined = list(zip(self.filenames, self.labels))
            np.random.shuffle(combined)
            # --- 细微但重要的修改：确保解包后是列表 ---
            # zip(*...) is the inverse of zip
            self.filenames, self.labels = list(zip(*combined))

    def __data_generation(self, batch_filenames, batch_labels):
        X = np.empty((len(batch_filenames), *INPUT_SHAPE))
        y = np.empty((len(batch_filenames)), dtype=int)

        for i, filename in enumerate(batch_filenames):
            spec_path = os.path.join(self.features_dir, f"{filename}.npy")
            spectrogram = np.load(spec_path)

            # --- 新增功能：只对训练集的Abnormal样本做数据增强 ---
            if self.is_train and batch_labels[i] == 1:
                if np.random.rand() > 0.5:
                    noise_amp = 0.005 * np.random.uniform() * np.amax(spectrogram)
                    spectrogram = spectrogram + noise_amp * np.random.normal(size=spectrogram.shape)
            
            X[i,] = np.expand_dims(spectrogram, axis=-1)
            y[i] = batch_labels[i]

        return X, y

# 实例化训练集和验证集的生成器
train_generator = HeartSoundGenerator(TRAIN_CSV_PATH, os.path.join(FEATURES_BASE_DIR, 'train'), BATCH_SIZE, is_train=True)
val_generator = HeartSoundGenerator(VAL_CSV_PATH, os.path.join(FEATURES_BASE_DIR, 'val'), BATCH_SIZE, is_train=False)

# --- 3. 构建轻量级CNN模型 ---
print("--- Building CNN model ---")
model = Sequential([
    Input(shape=INPUT_SHAPE),
    # ... (模型结构保持不变) ...
    Conv2D(filters=16, kernel_size=(3, 3), activation='relu', padding='same'),
    MaxPooling2D(pool_size=(2, 2)),
    Conv2D(filters=32, kernel_size=(3, 3), activation='relu', padding='same'),
    MaxPooling2D(pool_size=(2, 2)),
    Conv2D(filters=64, kernel_size=(3, 3), activation='relu', padding='same'),
    MaxPooling2D(pool_size=(2, 2)),
    Flatten(),
    Dense(64, activation='relu'),
    Dropout(0.5),
    Dense(1, activation='sigmoid')
])
model.summary()

# --- 4. 编译模型 ---
print("\n--- Compiling model ---")
model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])

# --- 5. 配置回调函数 ---
print("\n--- Configuring Callbacks ---")
# TensorBoard 日志
log_dir = "logs/fit/" + datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
tensorboard_callback = TensorBoard(log_dir=log_dir, histogram_freq=1)
print(f"TensorBoard logs will be saved to: {log_dir}")
print("After training starts, run this in a new terminal: tensorboard --logdir logs")

# EarlyStopping
early_stopping = EarlyStopping(monitor='val_loss', patience=3, verbose=1, restore_best_weights=True)
print("Early stopping is enabled.")

# ModelCheckpoint
model_checkpoint = ModelCheckpoint(
    'heart_sound_best_model.h5', 
    monitor='val_loss', 
    save_best_only=True, 
    verbose=1
)
print("Model checkpoint is enabled.")

# --- 6. 训练模型 ---
print("\n--- Starting model training ---")
class_weights = {0: 1, 1: 3}

history = model.fit(
    train_generator,
    epochs=EPOCHS,
    validation_data=val_generator,
    workers=0,
    callbacks=[tensorboard_callback, early_stopping, model_checkpoint],
    class_weight=class_weights
)

# --- 7. 保存最终模型 ---
print("\n--- Training complete, saving final model ---")
model.save('heart_sound_final_model.h5')
print("Final model saved as heart_sound_final_model.h5")

# --- 8. 详细评估 ---
print("\n--- Starting final evaluation on the validation set (using the best weights) ---")
y_true = np.array(val_generator.labels)
predictions_proba = model.predict(val_generator, verbose=1)
y_pred = (predictions_proba > 0.5).astype(int)
cm = confusion_matrix(y_true, y_pred)
class_names = ['Normal (-1)', 'Abnormal (1)']
plt.figure(figsize=(8, 6))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=class_names, yticklabels=class_names)
plt.title('Confusion Matrix')
plt.ylabel('True Label')
plt.xlabel('Predicted Label')
plt.show()

print("\n--- Classification Report ---")
print(classification_report(y_true, y_pred, target_names=class_names))

# --- 9. 结果归档 ---
print("\n--- Sorting validation files based on prediction results ---")
RESULTS_DIR = r"D:\_Capstone_\2025_New_Project\training\evaluation_results"
tp_dir = os.path.join(RESULTS_DIR, 'True_Positives_Correctly_Abnormal')
tn_dir = os.path.join(RESULTS_DIR, 'True_Negatives_Correctly_Normal')
fp_dir = os.path.join(RESULTS_DIR, 'False_Positives_Mistakenly_Abnormal')
fn_dir = os.path.join(RESULTS_DIR, 'False_Negatives_Mistakenly_Normal')
for d in [tp_dir, tn_dir, fp_dir, fn_dir]:
    os.makedirs(d, exist_ok=True)
validation_filepaths = val_generator.df['filepath'].tolist()
for i in range(len(validation_filepaths)):
    original_path = validation_filepaths[i]
    true_label = y_true[i]
    pred_label = y_pred[i]
    if true_label == 1 and pred_label == 1:
        shutil.copy(original_path, tp_dir)
    elif true_label == 0 and pred_label == 0:
        shutil.copy(original_path, tn_dir)
    elif true_label == 0 and pred_label == 1:
        shutil.copy(original_path, fp_dir)
    elif true_label == 1 and pred_label == 0:
        shutil.copy(original_path, fn_dir)
print(f"\nSorting complete. Files have been copied to: {RESULTS_DIR}")
print("您可以重点关注 'False_Positives' (误判) 和 'False_Negatives' (漏判) 文件夹。")

