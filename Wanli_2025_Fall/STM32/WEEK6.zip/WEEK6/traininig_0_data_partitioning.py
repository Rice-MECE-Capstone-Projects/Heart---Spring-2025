import pandas as pd
from sklearn.model_selection import train_test_split

# 加载上一步生成的干净数据集
clean_csv_path = r"D:\_Capstone_\2025_New_Project\training\master_reference_processed.csv"
clean_df = pd.read_csv(clean_csv_path)

# 定义特征（文件路径）和标签
X = clean_df['filepath']
y = clean_df['label']

# 使用train_test_split进行划分
# test_size=0.2 表示划分出20%的数据作为验证集
# random_state=42 是一个随机种子，保证每次划分结果都一样，方便复现实验
# stratify=y 是最关键的一步，它会根据y（标签）来进行分层抽样
X_train, X_val, y_train, y_val = train_test_split(
    X, y, 
    test_size=0.1, 
    random_state=42, 
    stratify=y
)

# 将划分好的数据重新组合成DataFrame
train_df = pd.DataFrame({'filepath': X_train, 'label': y_train})
val_df = pd.DataFrame({'filepath': X_val, 'label': y_val})

# --- 验证划分结果 ---
print("--- Dataset Split Report ---")
print(f"Total number of original dataset: {len(clean_df)}")
print(f"Total number of training set: {len(train_df)}")
print(f"Total number of validation set: {len(val_df)}")
print("\n--- Label Distribution Check ---")
print("Label distribution in the original dataset:")
print(clean_df['label'].value_counts(normalize=True))
print("\nLabel distribution in the training set:")
print(train_df['label'].value_counts(normalize=True))
print("\nLabel distribution in the validation set:")
print(val_df['label'].value_counts(normalize=True))

# 保存最终的训练集和验证集文件列表
train_df.to_csv(r"D:\_Capstone_\2025_New_Project\training\train_set.csv", index=False)
val_df.to_csv(r"D:\_Capstone_\2025_New_Project\training\validation_set.csv", index=False)

print("\nSuccessfully saved the training and validation set information to train_set.csv and validation_set.csv")