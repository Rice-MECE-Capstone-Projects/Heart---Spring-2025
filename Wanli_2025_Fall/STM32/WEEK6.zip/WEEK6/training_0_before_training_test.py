# import pandas as pd
# import librosa # 用于音频处理
# import os
# from tqdm import tqdm # 用于显示进度条

# # 加载我们之前生成的总数据表
# master_csv_path = r"D:\_Capstone_\2025_New_Project\training\master_reference.csv"
# df = pd.read_csv(master_csv_path)

# # 存储检查结果
# error_files = []
# durations = []
# clean_df = []

# print(f"Starting to check {len(df)} audio files...")

# # 使用tqdm来显示进度
# for index, row in tqdm(df.iterrows(), total=df.shape[0]):
#     filepath = row['filepath']
#     try:
#         # 1. 尝试加载音频文件
#         # sr=None 表示使用文件的原始采样率
#         audio_data, sample_rate = librosa.load(filepath, sr=None)
        
#         # 2. 检查音频时长
#         duration = librosa.get_duration(y=audio_data, sr=sample_rate)
#         durations.append(duration)
        
#         # 如果时长过短，也认为是问题文件
#         if duration < 1.0:
#             error_files.append({'filepath': filepath, 'reason': 'Duration too short (< 1s)'})
#             continue
            
#         # 3. 检查是否为静音 (最大振幅是否接近0)
#         if audio_data.max() < 0.001:
#             error_files.append({'filepath': filepath, 'reason': 'Audio is silent'})
#             continue

#     except Exception as e:
#         # 如果加载过程中出现任何错误，就认为是文件损坏
#         error_files.append({'filepath': filepath, 'reason': f'File loading error: {e}'})

# # 将检查结果转换成DataFrame
# error_df = pd.DataFrame(error_files)
# df['duration'] = durations

# # 打印检查报告
# print("\n--- Data Quality Check Report ---")
# if not error_df.empty:
#     print(f"Found {len(error_df)} problematic files:")
#     print(error_df)
#     # 从主数据表中移除这些有问题的文件，得到一个干净的数据集
#     clean_df = df[~df['filepath'].isin(error_df['filepath'])]
#     print(f"\nAfter removing problematic files, {len(clean_df)} valid files remain.")
# else:
#     clean_df = df.copy()
#     print("Congratulations! All files are readable and valid.")

# print("\nAudio Duration Statistics:")
# print(df['duration'].describe())

# # 从主数据表中移除这些有问题的文件，得到一个干净的数据集
# # clean_df = df[~df['filepath'].isin(error_df['filepath'])]
# # print(f"\nAfter removing problematic files, {len(clean_df)} valid files remain.")

# # 保存干净的数据集以备后用
# clean_df.to_csv(r"D:\_Capstone_\2025_New_Project\training\master_reference_clean.csv", index=False)
# print("The clean dataset has been saved to master_reference_clean.csv")
#////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

import pandas as pd
import numpy as np
import librosa
import os
from tqdm import tqdm
import soundfile as sf  # <-- 新增导入：用于保存处理后的 .wav 文件
from scipy.signal import butter, sosfilt # <-- 新增导入：用于实现滤波器

# --- 1. 新功能配置 ---
# --------------------------------------------------------------------------
# 主开关：是否要执行预处理并保存新的音频文件
# 如果设为 False，脚本将只执行原有的数据质量检查。
PROCESS_AND_SAVE_AUDIO = True

# --- 标准化配置 ---
APPLY_NORMALIZATION = True
# 移除直流偏移 (将波形垂直居中在0.0)
REMOVE_DC_OFFSET = True
# 将峰值振幅标准化到的分贝值 (dBFS -相对于满刻度的分贝)
# -1.0 dB 是一个常用的值，可以防止削波失真。
TARGET_PEAK_DB = -1.0

# --- 低通滤波配置 ---
APPLY_LOWPASS_FILTER = True
# 滤波器的阶数。阶数越高，过渡带越窄，但可能引入相位失真。5是一个常用的起始值。
LOWPASS_FILTER_ORDER = 5
# 截止频率 (单位: Hz)。高于此频率的信号将被衰减。
# 心音的主要频率成分通常在20-400Hz范围内。
LOWPASS_CUTOFF_HZ = 400
# --------------------------------------------------------------------------


# --- 2. 路径配置 ---
# 输入的CSV文件 (建议使用您之前生成的 clean 版本)
INPUT_CSV_PATH = r"D:\_Capstone_\2025_New_Project\training\master_reference_clean.csv"

# 处理后文件的输出路径
PROCESSED_AUDIO_DIR = r"D:\_Capstone_\2025_New_Project\training\processed_audio"
PROCESSED_CSV_PATH = r"D:\_Capstone_\2025_New_Project\training\master_reference_processed.csv"


# --- 3. 辅助函数：巴特沃斯低通滤波器 ---
def butter_lowpass_filter(data, cutoff, fs, order=5):
    """
    对音频数据应用巴特沃斯低通滤波器。
    :param data: 音频数据 (numpy array)
    :param cutoff: 截止频率 (Hz)
    :param fs: 采样率 (Hz)
    :param order: 滤波器阶数
    :return: 滤波后的音频数据
    """
    nyq = 0.5 * fs  # 奈奎斯特频率
    normal_cutoff = cutoff / nyq
    # 使用'sos'输出格式以获得更好的数值稳定性
    sos = butter(order, normal_cutoff, btype='low', analog=False, output='sos')
    y = sosfilt(sos, data)
    return y


# --- 4. 主程序 ---
# 确保输出文件夹存在
if PROCESS_AND_SAVE_AUDIO:
    os.makedirs(PROCESSED_AUDIO_DIR, exist_ok=True)
    print(f"Processed audio files will be saved in: {PROCESSED_AUDIO_DIR}")

# 加载总数据表
df = pd.read_csv(INPUT_CSV_PATH)

# 存储检查和处理结果
error_files = []
processed_files_data = [] # 用于存储新文件的信息

print(f"Starting to check and process {len(df)} audio files...")

# 使用tqdm来显示进度
for index, row in tqdm(df.iterrows(), total=df.shape[0]):
    filepath = row['filepath']
    
    try:
        # 1. 尝试加载音频文件
        audio_data, sample_rate = librosa.load(filepath, sr=None)
        
        # 2. 检查音频时长 (原有的质量检查)
        duration = librosa.get_duration(y=audio_data, sr=sample_rate)
        if duration < 1.0:
            error_files.append({'filepath': filepath, 'reason': f'Duration too short ({duration:.2f}s)'})
            continue
            
        # 3. 检查是否为静音 (原有的质量检查)
        if np.max(np.abs(audio_data)) < 0.001:
            error_files.append({'filepath': filepath, 'reason': 'Audio is silent'})
            continue

        # --- 4. 如果主开关打开，则执行新的预处理步骤 ---
        if PROCESS_AND_SAVE_AUDIO:
            
            # --- 步骤 4.1: 标准化 ---
            if APPLY_NORMALIZATION:
                # 移除直流偏移
                if REMOVE_DC_OFFSET:
                    audio_data = audio_data - np.mean(audio_data)
                
                # 峰值振幅归一化
                peak_amplitude = np.max(np.abs(audio_data))
                if peak_amplitude > 0: # 避免除以零
                    # 计算目标振幅 (从dB转换为线性值)
                    target_amplitude = 10**(TARGET_PEAK_DB / 20.0)
                    # 计算并应用缩放因子
                    scaling_factor = target_amplitude / peak_amplitude
                    audio_data = audio_data * scaling_factor

            # --- 步骤 4.2: 低通滤波 ---
            if APPLY_LOWPASS_FILTER:
                audio_data = butter_lowpass_filter(
                    audio_data, 
                    LOWPASS_CUTOFF_HZ, 
                    sample_rate, 
                    order=LOWPASS_FILTER_ORDER
                )

            # --- 步骤 4.3: 保存处理后的文件 ---
            # 构建新文件的完整路径
            base_filename = os.path.basename(filepath)
            output_filepath = os.path.join(PROCESSED_AUDIO_DIR, base_filename)
            
            # 使用 soundfile 库保存，它可以正确处理浮点数格式的 .wav
            sf.write(output_filepath, audio_data, sample_rate)
            
            # 记录新文件的信息
            processed_files_data.append({
                'filepath': output_filepath,
                'label': row['label']
            })

    except Exception as e:
        # 如果加载或处理过程中出现任何错误
        error_files.append({'filepath': filepath, 'reason': f'Error during processing: {e}'})

# --- 5. 输出报告和结果 ---
print("\n--- Preprocessing finished ---")

# 打印错误文件报告
if error_files:
    error_df = pd.DataFrame(error_files)
    print(f"\nFound {len(error_df)} files that could not be processed:")
    print(error_df)
else:
    print("\nAll files were checked successfully.")

# 如果执行了处理，则保存新的CSV文件
if PROCESS_AND_SAVE_AUDIO:
    if processed_files_data:
        processed_df = pd.DataFrame(processed_files_data)
        processed_df.to_csv(PROCESSED_CSV_PATH, index=False)
        print(f"\nSuccessfully processed and saved {len(processed_df)} audio files.")
        print(f"The CSV list pointing to the new files has been saved to: {PROCESSED_CSV_PATH}")
    else:
        print("\nNo files were processed and saved.")
